package com.computerdatabase.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {
	
	private WebDriver driver;
	
	@FindBy(id="searchbox")
	private WebElement field_FilterByCompName;
	
	@FindBy(id="searchsubmit")
	private WebElement btn_FilterByName;
	
	@FindBy(xpath=".//*[@id='add']")
	private WebElement btn_AddNewComputer;
	
	@FindBy(xpath=".//*[@id='main']/table/tbody/tr/td[1]/a")
	private WebElement message;
	
	
	public void enter_ComputerName (String compName)
	{
		field_FilterByCompName.clear();
		field_FilterByCompName.sendKeys(compName);
	}
	
	public void click_FilterByName ()
	{
		btn_FilterByName.click();
	}
	
	public void click_AddNewComputer()
	{
		btn_AddNewComputer.click();
	}
	
	public HomePage (WebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public boolean isPageOpened(){
	       return message.getText().toString().contains("Play sample application � Computer database");
	   }
	
	

}
