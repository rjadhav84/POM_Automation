package com.computerdatabase.pages;

import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class AddComputerPage {
	
	private WebDriver driver;
	
	@FindBy(id="name")
	private WebElement enter_ComputerName;
	
	@FindBy(id="introduced")
	private WebElement enter_IntroducedDate;
	
	@FindBy(id="discontinued")
	private WebElement enter_DiscontinuedDate;

	@FindBy(id="company")
	private WebElement select_company;
	
	@FindBy(xpath=".//*[@id='main']/form/div/input")
	private WebElement click_CreateThisComputer;

		
	public void enter_ComputerName (String compname)
	{
		enter_ComputerName.clear();
		enter_ComputerName.sendKeys(compname);
	}
	
	public void enter_IntroducedDate (String iDate)
	{
		enter_IntroducedDate.clear();
		enter_IntroducedDate.sendKeys(iDate);
	}
	
	public void enter_DiscontinuedDate (String dDate)
	{
		enter_DiscontinuedDate.clear();
		enter_DiscontinuedDate.sendKeys(dDate);
	}
	
	public void select_Company ()
	{
		Select dropdown = new Select(select_company);
		List<WebElement> CompanyList = dropdown.getOptions();
		int TotalCount = CompanyList.size();
		System.out.println("Total Companies : "+TotalCount);
		Random R = new Random();
		int Index = R.nextInt(TotalCount);
		System.out.println("Random Selected Company :"+Index);
		dropdown.selectByIndex(Index);
	}
	
	public void click_CreateThisComputer ()
	{
		click_CreateThisComputer.click();
	}
		
	public AddComputerPage (WebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
}


