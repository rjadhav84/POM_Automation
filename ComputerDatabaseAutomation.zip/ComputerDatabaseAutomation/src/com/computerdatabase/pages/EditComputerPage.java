package com.computerdatabase.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class EditComputerPage {
	
	private WebDriver driver;
	
	@FindBy(xpath=".//*[@id='main']/table/tbody/tr/td[1]/a")
	private WebElement click_ComputerNameLink;
	
	@FindBy(xpath=".//*[@id='main']/form[1]/div/input")
	private WebElement click_SaveThisComputer;
	
	@FindBy(xpath=".//*[@id='main']/form[2]/input")
	private WebElement click_DeleteThisComputer;
	
	@FindBy (xpath=".//*[@id='main']/div[1]")
	private WebElement message;
	

	public void click_ComputerNameLink()
	{
		click_ComputerNameLink.click();
	}
	
	public void click_SaveThisComputer()
	{
		click_SaveThisComputer.click();
	}
	
	public void click_DeleteThisComputer()
	{
		click_DeleteThisComputer.click();
	}
	
	public EditComputerPage (WebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public boolean isPageOpened(){
	       return message.getText().toString().contains("has been updated");
	   }
	
	public boolean isPageDeleted(){
	       return message.getText().toString().contains("Done! Computer has been deleted");
	   }
	
	
	
	
}
