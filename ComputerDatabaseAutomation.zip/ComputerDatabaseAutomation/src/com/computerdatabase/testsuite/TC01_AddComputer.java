package com.computerdatabase.testsuite;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import com.computerdatabase.pages.AddComputerPage;
import com.computerdatabase.pages.HomePage;
import com.computerdatabase.pages.InitDriver;


public class TC01_AddComputer {
	
	
	public String URL = "http://computer-database.herokuapp.com/computers";
	public String compname = "RUSHIKESH01";
	public String iDate = "2010-01-01";
	public String dDate = "2011-01-01";
	WebDriver driver;
	
	public TC01_AddComputer()
	{
		
	InitDriver init = new InitDriver();
	driver = init.driver(); 
	driver.get(URL);
	driver.manage().window().maximize();
	
	HomePage home = new HomePage(driver);
	AddComputerPage comp = new AddComputerPage(driver);
	
	// Add a new Computer (Create Operation)
			
	home.click_AddNewComputer();
	comp.enter_ComputerName(compname);
	comp.enter_IntroducedDate(iDate);
	comp.enter_DiscontinuedDate(dDate);
	comp.select_Company();
	comp.click_CreateThisComputer();
	
	try {
		Assert.assertTrue(comp.isPageOpened());
		System.out.println("********* Computer Added Successfully *********");
		
		} catch (Error e) {
		System.out.println("********* Computer not added *********");
		}
	
	driver.close();
		
}
	
public static void main (String[] args) {
		
		TC01_AddComputer test1 = new TC01_AddComputer();
				
	}

}
