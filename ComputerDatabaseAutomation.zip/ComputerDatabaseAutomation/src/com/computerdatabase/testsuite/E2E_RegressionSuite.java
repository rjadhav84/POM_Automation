package com.computerdatabase.testsuite;

public class E2E_RegressionSuite {
	
	
	public static void main(String[] args) throws InterruptedException {
		
		TC01_AddComputer test1 = new TC01_AddComputer();
		
		TC02_OpenAndEditComputer test2 = new TC02_OpenAndEditComputer();
		
		TC03_DeleteComputer test3 = new TC03_DeleteComputer();
		
	}

}
