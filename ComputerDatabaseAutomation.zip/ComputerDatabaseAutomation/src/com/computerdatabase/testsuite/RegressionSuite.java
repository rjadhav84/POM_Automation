package com.computerdatabase.testsuite;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.computerdatabase.pages.AddComputerPage;
import com.computerdatabase.pages.EditComputerPage;
import com.computerdatabase.pages.HomePage;

public class RegressionSuite {
	
	static String driverType = "webdriver.chrome.driver";
	static String driverLoc = "F:\\Selenium R&D\\chromedriver_win32\\chromedriver.exe";
	static String URL = "http://computer-database.herokuapp.com/computers";
	
	static String compname = "RUSHIKESH01";
	static String iDate = "2010-01-01";
	static String dDate = "2011-01-01";
	
	static String New_iDate = "2014-01-01";
	static String New_dDate = "2015-01-01";
	

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty(driverType,driverLoc);
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		
		driver.get(URL);
		driver.manage().window().maximize();
							
		HomePage home = new HomePage(driver);
		AddComputerPage comp = new AddComputerPage(driver);
		EditComputerPage edit = new EditComputerPage(driver);
		
		
		// Add a new Computer (Create Operation)
				
		home.click_AddNewComputer();
		comp.enter_ComputerName(compname);
		comp.enter_IntroducedDate(iDate);
		comp.enter_DiscontinuedDate(dDate);
		comp.select_Company();
		comp.click_CreateThisComputer();
		
		// Filter by Name 
		
		home.enter_ComputerName(compname);
		home.click_FilterByName();
		
		// Open computer details (Read Operation)
		
		edit.click_ComputerNameLink();
		
		// Edit This Computer (Update Operation)
		
		comp.enter_IntroducedDate(New_iDate);
		comp.enter_DiscontinuedDate(New_dDate);
		comp.select_Company();
		edit.click_SaveThisComputer();
		
		// Filter by Name
		
		home.enter_ComputerName(compname);
		home.click_FilterByName();
		
		// Delete This Computer (Delete Operation)
		
		edit.click_ComputerNameLink();
		edit.click_DeleteThisComputer();

	}

}
