package com.computerdatabase.testsuite;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import com.computerdatabase.pages.AddComputerPage;
import com.computerdatabase.pages.EditComputerPage;
import com.computerdatabase.pages.HomePage;
import com.computerdatabase.pages.InitDriver;

public class TC02_OpenAndEditComputer {
	
	public String URL = "http://computer-database.herokuapp.com/computers";
	public String compname = "RUSHIKESH01";
	public String New_iDate = "2012-01-01";
	public String New_dDate = "2014-01-01";
	WebDriver driver;
	
	public TC02_OpenAndEditComputer()
	{
		
	InitDriver init = new InitDriver();
	driver = init.driver(); 
	driver.get(URL);
	driver.manage().window().maximize();
	
	HomePage home = new HomePage(driver);
	AddComputerPage comp = new AddComputerPage(driver);
	EditComputerPage edit = new EditComputerPage(driver); 
	
			// Filter by Name 
			home.enter_ComputerName(compname);
			home.click_FilterByName();
			
			// Open computer details (Read Operation)
			edit.click_ComputerNameLink();
			
			// Edit This Computer (Update Operation)
			comp.enter_IntroducedDate(New_iDate);
			comp.enter_DiscontinuedDate(New_dDate);
			comp.select_Company();
			edit.click_SaveThisComputer();
	
	try {
		Assert.assertTrue(edit.isPageOpened());
		System.out.println("********* Computer Edited Successfully *********");
		
		} catch (Error e) {
		System.out.println("********* Computer edit failed *********");
		}
	
	driver.close();
		
}
	
public static void main (String[] args) {
		
	TC02_OpenAndEditComputer test2 = new TC02_OpenAndEditComputer();
				
	}

}
