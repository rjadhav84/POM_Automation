package com.computerdatabase.testsuite;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import com.computerdatabase.pages.AddComputerPage;
import com.computerdatabase.pages.EditComputerPage;
import com.computerdatabase.pages.HomePage;
import com.computerdatabase.pages.InitDriver;

public class TC03_DeleteComputer {
	
	public String URL = "http://computer-database.herokuapp.com/computers";
	public String compname = "RUSHIKESH01";
	WebDriver driver;
	
	public TC03_DeleteComputer()
	{
		
	InitDriver init = new InitDriver();
	driver = init.driver(); 
	driver.get(URL);
	driver.manage().window().maximize();
	
	HomePage home = new HomePage(driver);
	EditComputerPage edit = new EditComputerPage(driver); 
	
	// Filter by Name
	
			home.enter_ComputerName(compname);
			home.click_FilterByName();
			
			// Delete This Computer (Delete Operation)
			
			edit.click_ComputerNameLink();
			edit.click_DeleteThisComputer();
	
	try {
		Assert.assertTrue(edit.isPageDeleted());
		System.out.println("********* Computer deleted Successfully *********");
		
		} catch (Error e) {
		System.out.println("********* Computer deletion failed *********");
		}
	
	driver.close();
		
}
	
public static void main (String[] args) {
		
	TC03_DeleteComputer test3 = new TC03_DeleteComputer();
				
	}

}
